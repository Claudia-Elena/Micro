#include "LCD.h"
#include <avr/io.h>

int main(){
  
   initLCD();

   while(1){
   
   }
}

